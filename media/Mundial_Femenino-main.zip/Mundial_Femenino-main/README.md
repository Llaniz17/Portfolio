# Mundial_Femenino
Analisis, limpieza y transformación de datos para la predicción de la selección campeona del mundial femenino 2023
Proximamente subiré el video explicativo en mi canal. 
Mientras puedes visitar uno de mis videos: https://youtu.be/d5J_wmbJ0Tg
