# Estadisticas_criminales_Bangladesh
Analisis, limpieza y transformación de datos para la predicción de estaciones policiales de acuerdo a los crímenes en Bangladesh 
Link video explicativo: https://unisimonedu-my.sharepoint.com/:v:/g/personal/j_llanes_unisimon_edu_co/ESDYW0DxfqJFg5V7DmZXFH8BfzqT1LK6JsttCbHX3li0Tg?e=pSrEax
Link de otro videos del canal de Youtube: https://www.youtube.com/watch?v=NjsoEBzPBWk&ab_channel=Llaniz
